Clean Canvas Bootstrap Theme

Credits:

- Macbook, iPad, iPhone, images 
http://medialoot.com/item/free-responsive-screen-mockup-pack/
http://pixeden.com/psd-web-elements/responsive-showcase-psd
- Lato Google webfont http://www.google.com/webfonts/specimen/Lato
- Social icons from http://medialoot.com/item/round-social-media-icons/
- Icons by Brankic1979 http://www.brankic1979.com/icons/
- Isotope commercial license


Changelog: 

Version 1.0.0
- Initial release

Version 1.2.0
- Updated Bootstrap version to 2.3.2
- Fixed bug with index banner slides
- Added jquery.countdown on coming soon

Version 2.0.0
- Updated Bootstrap version to 3.0
- Added Sass files to Bootstrap 3 version
- Fixed bug with dropdown menu on mobile devices for Bootstrap 2.3.2
- Several bug fixes and enhancements